package com.example.wetravel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeTravelApplicationTests {

    @Test
    void contextLoads() {
    }

}
