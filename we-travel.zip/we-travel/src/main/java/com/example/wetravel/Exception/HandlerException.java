package com.example.wetravel.Exception;

public class HandlerException extends Exception{
    public HandlerException(String message) {
        super(message);
    }
}
